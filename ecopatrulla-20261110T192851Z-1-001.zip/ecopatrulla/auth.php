<?php

declare(strict_types=1);

// Iniciar la sesión solo una vez.
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Verificar que el usuario haya iniciado sesión.
function require_login(): void
{
    if (!isset($_SESSION["usuario_id"])) {
        header("Location: ../login.php");
        exit();
    }
}

// Verificar que el usuario sea administrador.
function require_admin(): void
{
    require_login();

    if (!isset($_SESSION["rol"]) || $_SESSION["rol"] !== "administrador") {
        header("Location: ../index.php");
        exit();
    }
}