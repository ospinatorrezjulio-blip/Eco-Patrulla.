<?php

// Crear la conexión con la base de datos local de Ecopatrulla.
$conexion = new mysqli("localhost", "root", "", "ecopatrulla_db");

// Detener la ejecución si MySQL no está disponible o las credenciales son incorrectas.
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Usar UTF-8 para conservar correctamente tildes, eñes y demás caracteres del proyecto.
$conexion->set_charset("utf8mb4");

?>