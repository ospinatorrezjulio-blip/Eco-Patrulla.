<?php

include "conexion.php";

// Recibir y validar los datos del formulario antes de guardarlos en MySQL.
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = trim($_POST["nombre"] ?? "");
    $documento = trim($_POST["documento"] ?? "");
    $usuario = trim($_POST["usuario"] ?? "");
    $correo = trim($_POST["correo"] ?? "");
    $celular = trim($_POST["celular"] ?? "");
    $grupo = trim($_POST["grupo"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "");
    $genero = trim($_POST["genero"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmar_password = $_POST["confirmar_password"] ?? "";

    // Verificar que la persona haya aceptado los términos obligatorios.
    if (!isset($_POST["terminos"])) {
        die("Debes aceptar los términos y condiciones.");
    }

    if ($nombre === "" || $documento === "" || $usuario === "" || $correo === "" ||
        $celular === "" || $grupo === "" || $fecha_nacimiento === "" || $genero === "" ||
        !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        die("Completa correctamente todos los campos del formulario.");
    }

    // Confirmar que ambas cajas de contraseña tengan el mismo valor.
    if ($password !== $confirmar_password) {
        die("Las contraseñas no coinciden.");
    }

    // Limitar grupo y género a las opciones que ofrece la interfaz.
    $gruposPermitidos = [
        "10-1", "10-2", "10-3", "10-4", "10-5", "10-6", "10-7",
        "11-1", "11-2", "11-3", "11-4", "11-5", "11-6", "11-7"
    ];
    $generosPermitidos = ["Masculino", "Femenino", "Otro", "Prefiero no decirlo"];

    if ($password === "" || !in_array($grupo, $gruposPermitidos, true) ||
        !in_array($genero, $generosPermitidos, true)) {
        die("Completa correctamente todos los campos del formulario.");
    }

    // Guardar únicamente un hash seguro y nunca la contraseña en texto plano.
    $password_segura = password_hash($password, PASSWORD_DEFAULT);

    // Insertar el nuevo usuario mediante parámetros para evitar inyección SQL.
    $sql = "INSERT INTO usuarios 
    (nombre, documento, usuario, correo, celular, grupo, fecha_nacimiento, genero, password, terminos)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        die("No se pudo preparar el registro: " . $conexion->error);
    }

    $stmt->bind_param(
        "sssssssss",
        $nombre,
        $documento,
        $usuario,
        $correo,
        $celular,
        $grupo,
        $fecha_nacimiento,
        $genero,
        $password_segura
    );

    if ($stmt->execute()) {

    $stmt->close();
    $conexion->close();
    header("Location: index.php");
    exit();

    } else {

    echo "Error al registrar el usuario: " . $stmt->error;

    }

    $stmt->close();
    $conexion->close();
}

?>
<!DOCTYPE html>
<!-- Indica que el documento utiliza HTML5 -->

<html lang="es">
<!-- Inicio del documento HTML y establece el idioma en español -->

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecopatrulla | Crear cuenta</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">

    <!-- Optimiza la conexión con el servidor de las fuentes -->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!-- Importa las fuentes Playfair Display y DM Sans -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Archivo CSS principal -->
    <link rel="stylesheet" href="styles.css">

    <!-- Archivo CSS adicional -->
    <link rel="stylesheet" href="extra.css">

<style>


/* =======================
   ESTILOS GENERALES
======================= */

/* Color de fondo de toda la página */
body{
    background:#0f2518;
}

/* Contenedor principal del formulario */
.register{

    /* Se separa del encabezado */
    margin-top:72px;

    /* Ocupa toda la altura de la pantalla */
    min-height:calc(100vh - 72px);

    /* Activa Flexbox */
    display:flex;

    /* Centra horizontalmente */
    justify-content:center;

    /* Centra verticalmente */
    align-items:flex-start;

    /* Espacio interno */
    padding:42px 20px 64px;

    /* Fondo con degradados y efectos */
    background:
    radial-gradient(circle at top left,#38a66f25,transparent 40%),
    radial-gradient(circle at bottom right,#10b98120,transparent 45%),
    linear-gradient(160deg,#0f2518,#173a29,#0f2518);

}

/* Tarjeta donde está el formulario */
.card{

    width:700px;
    max-width:100%;

    padding:45px;

    border-radius:30px;

    /* Fondo transparente */
    background:rgba(255,255,255,.08);

    /* Efecto vidrio */
    backdrop-filter:blur(18px);

    border:1px solid rgba(255,255,255,.12);

    box-shadow:0 20px 60px rgba(0,0,0,.35);

    color:white;

}

/* Título principal */
.card h1{

    font-family:'Playfair Display',serif;

    text-align:center;

    font-size:2.7rem;

    margin-bottom:10px;

}

/* Texto descriptivo */
.card p{

    text-align:center;

    margin-bottom:35px;

    color:#d7d7d7;

}

/* Icono circular del usuario */
.avatar{

    width:120px;
    height:120px;

    margin:auto;
    margin-bottom:20px;

    border-radius:50%;

    background:linear-gradient(135deg,#38a66f,#10b981);

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:55px;

}

/* Distribuye los campos en dos columnas */
.grid{

    display:grid;

    grid-template-columns:repeat(2,1fr);

    gap:20px;

}

/* Agrupa cada etiqueta con su campo */
.group{

    margin-bottom:18px;

}

/* Diseño de las etiquetas */
.group label{

    display:block;

    margin-bottom:8px;

    font-weight:600;

}

/* Diseño de los campos de texto y listas */
.group input,
.group select{

    width:100%;

    padding:15px;

    border:none;

    border-radius:15px;

    background:rgba(255,255,255,.12);

    color:white;

    font-size:15px;

    outline:none;

}

/* Color del texto de ejemplo */
.group input::placeholder{

    color:#dddddd;

}

/* Color del texto del select */
.group select{

    color:white;

}

/* Color de las opciones del select */
.group option{

    color:black;

}

/* Contenedor del checkbox */
.checkbox{

    display:flex;

    gap:10px;

    margin:20px 0;

    align-items:center;

}

/* Diseño del botón */
button{

    width:100%;

    padding: 16px;

    margin-left: 0;

    background:#38a66f;

    border:none;

    border-radius:19px;

    font-size:17px;

    font-weight:bold;

    color:white;

    cursor:pointer;

    transition:.3s;

}

/* Animación cuando el mouse pasa sobre el botón */
button:hover{

    background:#2b8657;

    transform:translateY(-3px);

}

/* Texto para iniciar sesión */
.login{

    margin-top:25px;

    text-align:center;

}

/* Diseño del enlace */
.login a{

    color:#8be5b3;

    text-decoration:none;

    font-weight:bold;

}

/* Efecto al pasar el mouse */
.login a:hover{

    text-decoration:underline;

}

            .logotipo__icono-secundario {
  width: 100px; height: 100px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, var(--green-600), var(--emerald));
  border-radius: 10px;
  box-shadow: 0 2px 12px rgba(30,77,56,.25);
  transition: transform .3s var(--ease-spring), box-shadow .3s;
}
.logotipo__icono-secundario {
  border-radius: 50%;
  box-shadow: 0 4px 12px rgba(56, 166, 111, 0.3);
}
.logotipo:hover .logotipo__icono-secundario {
  box-shadow: 0 6px 20px rgba(56, 166, 111, 0.5);
}
        .login-hero{

            min-height:100vh;
            margin-top:72px;

            display:flex;
            justify-content:center;
            align-items:center;

            background:
            radial-gradient(circle at top left,#2d7a5530,transparent 40%),
            radial-gradient(circle at bottom right,#10b98120,transparent 40%),
            linear-gradient(160deg,#0f2518,#173a29,#0f2518);

            overflow:hidden;
            position:relative;

        }

        .login-hero::before{

            content:"";

            position:absolute;
            width:650px;
            height:650px;

            background:rgba(56,166,111,.15);

            border-radius:50%;

            filter:blur(120px);

            animation:floatGlow 8s ease-in-out infinite;

        }

/* Diseño adaptable para celulares */
@media(max-width:700px){

    /* Cambia de dos columnas a una */
    .grid{

        grid-template-columns:1fr;

    }

    /* Reduce el espacio interno */
    .card{

        padding:30px;

    }

    .register{

        padding:28px 14px 48px;

    }
    

}

</style>

</head>

<body>

<!-- ======================
     ENCABEZADO
====================== -->

<header class="header">

    <div class="header__inner">

        <!-- Logo que lleva a la página principal -->
        <a href="index.php" class="logo">

            <!-- Icono SVG -->
            <div class="logo__icon">

                <!-- Dibujo del logo -->
                <svg viewBox="0 0 24 24">

                    <!-- Tallo -->
                    <path/>

                    <!-- Hoja -->
                    <path/>

                    <!-- Hoja pequeña -->
                    <path/>

                </svg>

            </div>

            <!-- Nombre del sitio -->
            <span class="logo__text">Ecopatrulla</span>

        </a>

        <button class="theme-toggle" aria-label="Cambiar tema">
            <svg class="icono-sol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
            <svg class="icono-luna" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
        </button>

        <button class="nav-toggle" aria-label="Abrir menú">
            <span></span>
            <span></span>
            <span></span>
        </button>

        <!-- Menú de navegación -->
        <nav class="nav">

            <div class="nav__pill"></div>

            <a href="index.php" class="nav__link">Inicio</a>

            <a href="actividades.php" class="nav__link">Actividades</a>

            <a href="recursos.php" class="nav__link">Recursos</a>
        </nav>

        <!-- Botón para regresar al inicio -->
        <a href="index.php" class="header__cta">

            Volver

        </a>

    </div>

</header>

<!-- ======================
     FORMULARIO
====================== -->

<section class="register">

<div class="card">

    <!-- Título -->
    <h1>Crear cuenta</h1>

    <!-- Descripción -->
    <p>Completa el siguiente formulario para registrarte en Ecopatrulla.</p>

    <!-- Formulario -->
    <form action="registro.php" method="post">

        <!-- Contenedor de los campos -->
        <div class="grid">

            <!-- Campo Nombre -->
            <div class="group">
                <label>Nombre completo</label>
                <input type="text" name="nombre" required>


            </div>

            <!-- Documento -->
            <div class="group">
                <label>Documento</label>
                <input type="text" name="documento" inputmode="numeric" required>
            </div>

            <!-- Usuario -->
            <div class="group">
                <label>Usuario</label>
               <input type="text" name="usuario" required>
            </div>

            <!-- Correo -->
            <div class="group">
                <label>Correo electrónico</label>
                <input type="email" name="correo" required>
            </div>

            <!-- Celular -->
            <div class="group">
                <label>Celular</label>
                <input type="tel" name="celular" required>
            </div>

            <!-- Grupo -->
            <div class="group">

                <label>Grupo</label>

                <!-- Lista desplegable -->
               <select name="grupo" required>
    <option value="">Seleccione...</option>

    <option value="10-1">10-1</option>
    <option value="10-2">10-2</option>
    <option value="10-3">10-3</option>
    <option value="10-4">10-4</option>
    <option value="10-5">10-5</option>
    <option value="10-6">10-6</option>
    <option value="10-7">10-7</option>

    <option value="11-1">11-1</option>
    <option value="11-2">11-2</option>
    <option value="11-3">11-3</option>
    <option value="11-4">11-4</option>
    <option value="11-5">11-5</option>
    <option value="11-6">11-6</option>
    <option value="11-7">11-7</option>
</select>
            </div>

            <!-- Fecha -->
            <div class="group">
                <label>Fecha de nacimiento</label>
                <input type="date" name="fecha_nacimiento" required>
            </div>

            <!-- Género -->
            <div class="group">

                <label>Género</label>

               <select name="genero" required>

                    <option value="">Seleccione...</option>
                    <option>Masculino</option>
                    <option>Femenino</option>
                    <option>Otro</option>
                    <option>Prefiero no decirlo</option>

                </select>

            </div>

            <!-- Contraseña -->
            <div class="group">
                <label>Contraseña</label>
               <input type="password" name="password" required>
            </div>

            <!-- Confirmación -->
            <div class="group">
                <label>Confirmar contraseña</label>
                <input type="password" name="confirmar_password" required>
            </div>

        </div>

        <!-- Aceptación de términos -->
        <div class="checkbox">

            <input type="checkbox" name="terminos" value="1" required>

            <label>Acepto los términos y condiciones.</label>

        </div>

        <!-- Botón para enviar -->
        <button type="submit">

            Crear cuenta

        </button>

    </form>

    <!-- Enlace para iniciar sesión -->
    <div class="login">

        ¿Ya tienes una cuenta?

        <br><br>

        <a href="login.php">

            Iniciar sesión

        </a>

    </div>

</div>

</section>

<!-- ======================
     ARCHIVOS JAVASCRIPT
====================== -->

<!-- Controla el menú de navegación -->
<script src="nav.js"></script>

<!-- Funciones principales de la página -->
<script src="main.js"></script>
<!-- Funciones adicionales del proyecto -->

</body>
</html>