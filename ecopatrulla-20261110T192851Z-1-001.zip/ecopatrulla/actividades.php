<?php
declare(strict_types=1);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ecopatrulla – Actividades</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="extra.css" />
</head>
<body>

<!-- ─── ENCABEZADO: identidad, tema y navegación principal ─── -->
<header class="header">
  <div class="header__inner">
    <a href="index.php" class="logo">
      <div class="logo__icon">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 22V13" stroke="white" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 13C12 13 8 12 6 9C4.5 6.5 5.5 3 8 2C9.5 1.3 11.2 1.8 12 3C12.8 1.8 14.5 1.3 16 2C18.5 3 19.5 6.5 18 9C16 12 12 13 12 13Z" fill="white" opacity="0.9"/>
          <path d="M12 16C12 16 9 15.5 7.5 14C6 12.5 6.5 10 8 9.5C9 9.1 10.2 9.5 11 10.2C11.4 9.5 12.6 9.1 13.6 9.5C15.1 10 15.6 12.5 14.1 14C12.6 15.5 12 16 12 16Z" fill="white"/>
        </svg>
      </div>
      <span class="logo__text">Ecopatrulla</span>
    </a>
    
    <button class="theme-toggle" aria-label="Cambiar tema">
      <svg class="icono-sol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
      <svg class="icono-luna" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
    </button>

    <button class="nav-toggle" aria-label="Abrir menú">
      <span></span><span></span><span></span>
    </button>
    <nav class="nav">
      <div class="nav__pill"></div>
      <a href="index.php"       class="nav__link">Inicio</a>
      <a href="actividades.php" class="nav__link nav__link--active">Actividades</a>
      <a href="recursos.php"    class="nav__link">Recursos</a>
    </nav>
    <a href="recursos.php" class="header__cta">
      Recursos
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
  </div>
</header>

<!-- ─── PORTADA: presentación de la sección de actividades ─── -->
<section class="page-hero page-hero--actividades">
  <div class="page-hero__bg"></div>
  <div class="page-hero__grain"></div>
  <span class="leaf leaf--1">🍃</span>
  <span class="leaf leaf--3">🌿</span>
  <span class="leaf leaf--5">🌱</span>
  <span class="leaf leaf--2">🍂</span>
  <div class="container page-hero__content">
    <span class="section-tag section-tag--light">Participa</span>
    <h1 class="page-hero__title">Actividades<br/><em>ecológicas</em></h1>
    <p class="page-hero__desc">Conoce las iniciativas que Ecopatrulla promueve para que puedas convertirte en parte activa del cambio ambiental.</p>
  </div>
</section>

<!-- ─── FRANJA INTRODUCTORIA: resumen de las categorías de actividad ─── -->
<section class="act-intro">
  <div class="container">
    <div class="act-intro__strip">
      <div class="act-intro__item">
        <span class="act-intro__num">01</span>
        <span>Reciclaje</span>
      </div>
      <div class="act-intro__divider"></div>
      <div class="act-intro__item">
        <span class="act-intro__num">02</span>
        <span>Limpieza</span>
      </div>
      <div class="act-intro__divider"></div>
      <div class="act-intro__item">
        <span class="act-intro__num">03</span>
        <span>Educación</span>
      </div>
      <div class="act-intro__divider"></div>
      <div class="act-intro__item">
        <span class="act-intro__num">04</span>
        <span>Jardines</span>
      </div>
    </div>
  </div>
</section>

<!-- ─── ACTIVIDADES: tarjetas con las iniciativas ambientales ─── -->
<section class="actividades">
  <div class="container">

    <!-- 1. Jornadas de reciclaje -->
    <article class="act-card act-card--horizontal">
      <div class="act-card__visual act-card__visual--recycle">
        <div class="act-card__pattern"></div>
        <span class="act-card__big-icon">♻️</span>
        <a href="calculadora.php" class="act-card__cta">✦ Participar</a>
      </div>
      <div class="act-card__body">
        <span class="act-card__tag">Actividad principal</span>
        <h2 class="act-card__title">Jornadas de Reciclaje</h2>
        <p class="act-card__desc">Las jornadas de reciclaje son uno de los pilares de Ecopatrulla. En estas sesiones, los participantes aprenden a clasificar residuos correctamente, conocen los materiales que se pueden reutilizar y practican técnicas de reciclaje creativo.</p>
        <div class="act-card__details">
          <div class="act-card__detail">
            <span class="act-card__detail-label">Frecuencia</span>
            <span class="act-card__detail-value">Mensual</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Duración</span>
            <span class="act-card__detail-value">3 horas</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Nivel</span>
            <span class="act-card__detail-value">Todos</span>
          </div>
        </div>
      </div>
    </article>

    <!-- 2. Limpieza de zonas verdes -->
    <article class="act-card act-card--horizontal act-card--reverse">
      <div class="act-card__visual act-card__visual--green">
        <div class="act-card__pattern"></div>
        <span class="act-card__big-icon">🌳</span>
        <a href="calculadora.php" class="act-card__cta">✦ Participar</a>
      </div>
      <div class="act-card__body">
        <span class="act-card__tag">Acción comunitaria</span>
        <h2 class="act-card__title">Limpieza de Zonas Verdes</h2>
        <p class="act-card__desc">Organizamos jornadas comunitarias donde vecinos y voluntarios se unen para limpiar parques, jardines públicos y áreas naturales cercanas. El objetivo es recuperar y preservar los espacios verdes de nuestra comunidad.</p>
        <div class="act-card__details">
          <div class="act-card__detail">
            <span class="act-card__detail-label">Frecuencia</span>
            <span class="act-card__detail-value">Quincenal</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Duración</span>
            <span class="act-card__detail-value">2 horas</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Nivel</span>
            <span class="act-card__detail-value">Familia</span>
          </div>
        </div>
      </div>
    </article>

    <!-- 3. Campañas educativas -->
    <article class="act-card act-card--horizontal">
      <div class="act-card__visual act-card__visual--edu">
        <div class="act-card__pattern"></div>
        <span class="act-card__big-icon">📖</span>
        <a href="calculadora.php" class="act-card__cta">✦ Participar</a>
      </div>
      <div class="act-card__body">
        <span class="act-card__tag">Campaña</span>
        <h2 class="act-card__title">Campañas Educativas</h2>
        <p class="act-card__desc">A través de talleres, charlas y materiales visuales, las campañas educativas de Ecopatrulla difunden conocimiento sobre el impacto ambiental, la biodiversidad y las acciones individuales que hacen la diferencia.</p>
        <div class="act-card__details">
          <div class="act-card__detail">
            <span class="act-card__detail-label">Frecuencia</span>
            <span class="act-card__detail-value">Semanal</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Formato</span>
            <span class="act-card__detail-value">En línea / Presencial</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Nivel</span>
            <span class="act-card__detail-value">Adultos</span>
          </div>
        </div>
      </div>
    </article>

    <!-- 4. Jardines urbanos -->
    <article class="act-card act-card--horizontal act-card--reverse">
      <div class="act-card__visual act-card__visual--urban">
        <div class="act-card__pattern"></div>
        <span class="act-card__big-icon">🌻</span>
        <a href="calculadora.php" class="act-card__cta">✦ Participar</a>
      </div>
      <div class="act-card__body">
        <span class="act-card__tag">Proyecto sostenible</span>
        <h2 class="act-card__title">Jardines Urbanos</h2>
        <p class="act-card__desc">Promovemos la creación de jardines urbanos en azoteas y espacios comunitarios. Estos jardines no solo producen alimentos, sino que también mejoran la calidad del aire y generan espacios de bienestar en la ciudad.</p>
        <div class="act-card__details">
          <div class="act-card__detail">
            <span class="act-card__detail-label">Tipo</span>
            <span class="act-card__detail-value">Proyecto continuo</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Participación</span>
            <span class="act-card__detail-value">Abierta</span>
          </div>
          <div class="act-card__detail">
            <span class="act-card__detail-label">Nivel</span>
            <span class="act-card__detail-value">Todos</span>
          </div>
        </div>
      </div>
    </article>

  </div>
</section>

<!-- ─── PIE DE PÁGINA: enlaces secundarios y datos del proyecto ─── -->
<div class="footer-wave">
  <svg viewBox="0 0 1440 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0,40 C240,80 480,0 720,40 C960,80 1200,0 1440,40 L1440,80 L0,80 Z" fill="#0f2518"/>
  </svg>
</div>
<footer class="footer">
  <div class="container">
    <div class="footer__grid">
      <div class="footer__brand-col">
        <a href="index.php" class="logotipo">
          <div class="logotipo__icono">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 22V13" stroke="white" stroke-width="2" stroke-linecap="round"/>
              <path d="M12 13C12 13 8 12 6 9C4.5 6.5 5.5 3 8 2C9.5 1.3 11.2 1.8 12 3C12.8 1.8 14.5 1.3 16 2C18.5 3 19.5 6.5 18 9C16 12 12 13 12 13Z" fill="white" opacity="0.9"/>
            </svg>
          </div>
          <span class="logotipo__texto">Ecopatrulla</span>
        </a>
        <p>Una plataforma educativa digital dedicada a la conciencia ambiental y al cambio sostenible en nuestras comunidades.</p>
      </div>
      <div class="footer__col">
        <h4>Explorar</h4>
        <ul>
          <li><a href="index.php">Inicio</a></li>
          <li><a href="actividades.php">Actividades</a></li>
          <li><a href="recursos.php">Recursos Digitales</a></li>
        </ul>
      </div>
      <div class="footer__col">
        <h4>Actividades</h4>
        <ul>
          <li><a href="actividades.php">Jornadas de Reciclaje</a></li>
          <li><a href="actividades.php">Limpieza de Zonas Verdes</a></li>
          <li><a href="actividades.php">Campañas Educativas</a></li>
          <li><a href="actividades.php">Jardines Urbanos</a></li>
        </ul>
      </div>
      <div class="footer__col">
        <h4>Recursos</h4>
        <ul>
          <li><a href="recursos.php">Videos educativos</a></li>
          <li><a href="recursos.php">Guías interactivas</a></li>
          <li><a href="recursos.php">Infografías</a></li>
          <li><a href="recursos.php">Libros digitales</a></li>
        </ul>
      </div>
    </div>
    <div class="footer__bottom">
      <p class="footer__quote">"La naturaleza no es un recurso ilimitado; es un regalo que debemos cuidar entre todos."</p>
      <p class="footer__copy">© 2025 Ecopatrulla · Proyecto educativo ambiental</p>
    </div>
  </div>
</footer>

<script src="nav.js"></script>
<script src="main.js"></script>
<script src="experience.js"></script>
</body>
</html>
