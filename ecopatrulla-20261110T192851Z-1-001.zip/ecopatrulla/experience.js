
class EcoExperience {
  constructor() {
    // Activar las experiencias visuales compartidas por las páginas públicas.
    this.initOrb();
    this.initMagnetic();
    this.initParticles();
    this.initScroll();
  }

  // 1. ORBE ECOLÓGICO: menú flotante con acciones rápidas.
  initOrb() {
    // Insertar el menú y el lienzo de partículas una sola vez en el documento.
    const orbHTML = `
      <div class="eco-orb-container">
        <div class="eco-orb-menu">
          <button class="orb-btn" id="btn-top" aria-label="Volver arriba" title="Subir">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 15l-6-6-6 6"/></svg>
          </button>
          <button class="orb-btn" id="btn-zen" aria-label="Modo Zen" title="Modo Zen (Partículas)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v3m0 12v3M3 12h3m12 0h3M5.6 5.6l2.1 2.1m8.5 8.5l2.1 2.1M5.6 18.4l2.1-2.1m8.5-8.5l2.1-2.1M12 12a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/></svg>
          </button>
        </div>
        <button class="eco-orb-main" aria-label="Menú Eco" aria-expanded="false">
          <span class="orb-icon">🍃</span>
        </button>
      </div>
      <canvas id="zen-canvas" style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:9990;opacity:0;transition:opacity 1s ease;"></canvas>
    `;
    document.body.insertAdjacentHTML('beforeend', orbHTML);

    const mainBtn = document.querySelector('.eco-orb-main');
    const container = document.querySelector('.eco-orb-container');
    const topBtn = document.getElementById('btn-top');
    const zenBtn = document.getElementById('btn-zen');
    const canvas = document.getElementById('zen-canvas');

    // Abrir o cerrar las acciones secundarias del orbe.
    mainBtn.addEventListener('click', () => {
      container.classList.toggle('active');
      const expanded = container.classList.contains('active');
      mainBtn.setAttribute('aria-expanded', expanded);
    });
    // Llevar suavemente al usuario al inicio de la página.
    topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    // Alternar el modo Zen, que muestra u oculta las partículas ambientales.
    zenBtn.addEventListener('click', () => {
      const isActive = canvas.style.opacity === '1';
      canvas.style.opacity = isActive ? '0' : '1';
      zenBtn.classList.toggle('active');
      if (!isActive) this.startParticles(); else this.stopParticles();
    });
  }

  initMagnetic() {
    // Activar el efecto magnético solo en dispositivos que admiten hover.
    if (window.matchMedia('(hover: hover)').matches) {
      const magneticElements = document.querySelectorAll('.btn, .nav__link, .header__cta, .logo, .theme-toggle');
      magneticElements.forEach(el => {
        el.addEventListener('mousemove', e => {
          const rect = el.getBoundingClientRect();
          const x = e.clientX - rect.left - rect.width / 2;
          const y = e.clientY - rect.top - rect.height / 2;
          el.style.transform = `translate(${x * 0.2}px, ${y * 0.2}px)`;
        });
        el.addEventListener('mouseleave', () => { el.style.transform = 'translate(0, 0)'; });
      });
    }
  }

  initParticles() {
    // Preparar el canvas y la lista de partículas para el modo Zen.
    this.canvas = document.getElementById('zen-canvas');
    this.ctx = this.canvas.getContext('2d');
    this.particles = [];
    this.animationId = null;
    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());
  }

  resizeCanvas() {
    // Ajustar la resolución del canvas al tamaño visible de la ventana.
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  startParticles() {
    // Crear las partículas iniciales y comenzar el ciclo de animación.
    if (this.animationId) return;
    for (let i = 0; i < 50; i++) {
      this.particles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        size: Math.random() * 3 + 1,
        speedX: Math.random() * 1 - 0.5,
        speedY: Math.random() * 1 - 0.5,
        opacity: Math.random() * 0.5 + 0.1
      });
    }
    this.animate();
  }

  stopParticles() {
    // Detener el ciclo y limpiar el canvas al salir del modo Zen.
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
      this.particles = [];
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
  }

  animate() {
    // Actualizar posiciones, reciclar partículas que salen de la pantalla y dibujarlas.
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.particles.forEach(p => {
      p.x += p.speedX;
      p.y += p.speedY;
      if (p.x < 0) p.x = this.canvas.width;
      if (p.x > this.canvas.width) p.x = 0;
      if (p.y < 0) p.y = this.canvas.height;
      if (p.y > this.canvas.height) p.y = 0;
      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(100, 255, 150, ${p.opacity})`;
      this.ctx.fill();
    });
    this.animationId = requestAnimationFrame(() => this.animate());
  }

  initScroll() {
    // Aplicar una aparición progresiva a secciones y tarjetas al entrar en pantalla.
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('visible');
      });
    }, { threshold: 0.1 });
    document.querySelectorAll('section, .card, article').forEach(el => {
      el.classList.add('fade-in-section');
      observer.observe(el);
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  // Crear la experiencia después de cargar el DOM.
  new EcoExperience();
});
