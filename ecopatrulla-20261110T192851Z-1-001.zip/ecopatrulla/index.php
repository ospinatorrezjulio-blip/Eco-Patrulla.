<?php
declare(strict_types=1);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ecopatrulla – Inicio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="extra.css" />
</head>
<body>

<!-- ─── ENCABEZADO ─── -->
<header class="header">
  <div class="header__inner">
    <a href="index.php" class="logo">
      <div class="logo__icon">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 22V13" stroke="white" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 13C12 13 8 12 6 9C4.5 6.5 5.5 3 8 2C9.5 1.3 11.2 1.8 12 3C12.8 1.8 14.5 1.3 16 2C18.5 3 19.5 6.5 18 9C16 12 12 13 12 13Z" fill="white" opacity="0.9"/>
          <path d="M12 16C12 16 9 15.5 7.5 14C6 12.5 6.5 10 8 9.5C9 9.1 10.2 9.5 11 10.2C11.4 9.5 12.6 9.1 13.6 9.5C15.1 10 15.6 12.5 14.1 14C12.6 15.5 12 16 12 16Z" fill="white"/>
        </svg>
      </div>
      <span class="logo__text">Ecopatrulla</span>
    </a>

    <button class="theme-toggle" aria-label="Cambiar tema">
      <svg class="icono-sol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
      <svg class="icono-luna" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
    </button>

    <button class="nav-toggle" aria-label="Abrir menú">
      <span></span><span></span><span></span>
    </button>

    <nav class="nav">
      <div class="nav__pill"></div>
      <a href="index.php"       class="nav__link nav__link--active">Inicio</a>
      <a href="actividades.php" class="nav__link">Actividades</a>
      <a href="recursos.php"    class="nav__link">Recursos</a>
    </nav>

    <a href="actividades.php" class="header__cta">
        Actividades
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
  </div>
</header>

<!-- ─── PORTADA ─── -->
<section class="hero">
  <div class="hero__bg"></div>
  <div class="hero__grain"></div>

  <!-- Partículas flotantes -->
  <div class="hero__particles">
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
    <div class="particle"></div>
  </div>

  <div class="hero__content">
    <!-- Izquierda: texto -->
    <div class="hero__text">
      <p class="hero__eyebrow">Conciencia ambiental para todos</p>
      <h1 class="hero__title">El planeta<br/><em>necesita</em><br/>tu ayuda.</h1>
      <p class="hero__desc">Cada pequeña acción cuenta. Juntos podemos proteger los ecosistemas, reducir nuestro impacto y construir un futuro más verde y sostenible.</p>
      <div class="hero__actions">
        <a href="actividades.php" class="btn btn--primary">
          Comienza la acción
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>
        <a href="recursos.php" class="btn btn--outline-light">Recursos digitales</a>
      </div>
    </div>

    <!-- Derecha: ilustración SVG -->
    <div class="hero__visual">
      <div class="hero__glow"></div>
      <svg class="hero-tree" viewBox="0 0 400 460" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Ilustración artística de un árbol grande y frondoso con pájaros volando alrededor, simbolizando la naturaleza">
        <!-- Suelo -->
        <ellipse cx="200" cy="420" rx="140" ry="18" fill="rgba(56,166,111,.15)"/>
        <!-- Tronco -->
        <path d="M185 420 C183 380 178 340 180 310 L220 310 C222 340 217 380 215 420 Z" fill="#3d6b4f"/>
        <path d="M185 420 C183 380 178 340 180 310 L195 310 C193 340 188 380 187 420 Z" fill="#2d5a40" opacity=".6"/>
        <!-- Raíces -->
        <path d="M185 418 Q170 428 155 435" stroke="#3d6b4f" stroke-width="5" stroke-linecap="round" fill="none"/>
        <path d="M185 420 Q160 432 142 440" stroke="#2d5a40" stroke-width="3.5" stroke-linecap="round" fill="none" opacity=".7"/>
        <path d="M215 418 Q230 428 245 435" stroke="#3d6b4f" stroke-width="5" stroke-linecap="round" fill="none"/>
        <path d="M215 420 Q240 432 258 440" stroke="#2d5a40" stroke-width="3.5" stroke-linecap="round" fill="none" opacity=".7"/>
        <!-- Capas de la copa (de atrás hacia delante) -->
        <ellipse cx="200" cy="210" rx="110" ry="100" fill="#1e6b45"/>
        <ellipse cx="145" cy="240" rx="70"  ry="65"  fill="#238f5a"/>
        <ellipse cx="255" cy="235" rx="75"  ry="68"  fill="#238f5a"/>
        <ellipse cx="200" cy="180" rx="95"  ry="82"  fill="#2aad6a"/>
        <ellipse cx="160" cy="200" rx="60"  ry="55"  fill="#35c47a" opacity=".9"/>
        <ellipse cx="240" cy="195" rx="65"  ry="58"  fill="#35c47a" opacity=".9"/>
        <ellipse cx="200" cy="155" rx="78"  ry="68"  fill="#3fd88a"/>
        <ellipse cx="200" cy="135" rx="55"  ry="48"  fill="#50e094"/>
        <!-- Burbujas de luz -->
        <circle cx="155" cy="175" r="12" fill="rgba(255,255,255,.08)"/>
        <circle cx="240" cy="160" r="8"  fill="rgba(255,255,255,.06)"/>
        <circle cx="200" cy="120" r="10" fill="rgba(255,255,255,.07)"/>
        <!-- Hojas flotantes alrededor del árbol -->
        <g opacity=".7">
          <ellipse cx="90"  cy="180" rx="7" ry="4" fill="#5cc490" transform="rotate(-20 90 180)"/>
          <ellipse cx="310" cy="200" rx="6" ry="3" fill="#8fdbb5" transform="rotate(15 310 200)"/>
          <ellipse cx="75"  cy="260" rx="5" ry="3" fill="#38a66f" transform="rotate(-10 75 260)" style="animation:leafDrift 6s 1s ease-in-out infinite"/>
          <ellipse cx="325" cy="150" rx="7" ry="3.5" fill="#5cc490" transform="rotate(25 325 150)" style="animation:leafDrift 7s 2s ease-in-out infinite"/>
          <ellipse cx="105" cy="120" rx="5" ry="2.5" fill="#8fdbb5" transform="rotate(-15 105 120)" style="animation:leafDrift 8s 0.5s ease-in-out infinite"/>
        </g>
        <!-- Pájaros pequeños (puntos) -->
        <g opacity=".45" fill="white">
          <path d="M60 100 Q65 96 70 100 Q75 96 80 100" stroke="white" stroke-width="1.5" fill="none"/>
          <path d="M290 70 Q294 67 298 70 Q302 67 306 70" stroke="white" stroke-width="1.2" fill="none"/>
        </g>
      </svg>
    </div>
  </div>

  <!-- Indicador de desplazamiento -->
  <div class="hero__scroll-hint">
    <span>Desplázate</span>
    <div class="scroll-line"></div>
  </div>
</section>

<!-- ─── ECO RETO (nuevo) ─── -->
<section class="eco-reto">
  <div class="container">
    <div class="eco-reto__card">
      <div class="eco-reto__content">
        <span class="eco-reto__tag">Desafío Diario</span>
        <h3 class="eco-reto__title" id="reto-title">Cargando reto...</h3>
        <p class="eco-reto__desc" id="reto-desc">Descubre tu misión ecológica de hoy.</p>
        <button class="btn btn--sm btn--white" id="btn-nuevo-reto">
          Nuevo reto 🔄
        </button>
      </div>
      <div class="eco-reto__visual">
        <div class="eco-reto__icon">🌱</div>
      </div>
    </div>
  </div>
</section>

<!-- ─── NOSOTROS ─── -->
<section class="about">
  <div class="container">
    <div class="about__grid">
      <div class="about__visual">
        <div class="about__frame">
          <div class="about__icons">
            <div class="about__icon-bubble"><span>♻️</span></div>
            <div class="about__icon-bubble about__icon-bubble--offset"><span>🌳</span></div>
            <div class="about__icon-bubble"><span>💧</span></div>
            <div class="about__icon-bubble about__icon-bubble--offset"><span>☀️</span></div>
          </div>
        </div>
        <div class="about__badge">
          <span>🌱</span> Proyecto activo desde 2023
        </div>
      </div>
      <div class="about__text">
        <span class="section-tag">¿Quiénes somos?</span>
        <h2 class="section-title">Conoce<br/><em>Ecopatrulla</em></h2>
        <p>Ecopatrulla es una plataforma educativa digital creada con el propósito de inspirar y movilizar a ciudadanos de todas las edades hacia una convivencia respetuosa con el medio ambiente.</p>
        <p>Nacida de la necesidad de generar conciencia, nuestra iniciativa combina información accesible, actividades prácticas y recursos multimedia para que cada persona pueda ser parte del cambio.</p>
      </div>
    </div>
  </div>
</section>

<!-- ─── OBJETIVOS ─── -->
<section class="objetivos">
  <div class="container"></div>
    <div class="objetivos__header">
      <span class="section-tag">Nuestros pilares</span>
      <h2 class="section-title">Objetivos del<br/><em>proyecto</em></h2>
    </div>
    <div class="objetivos__grid">
      <article class="obj-card obj-card--green">
        <div class="obj-card__stripe"></div>
        <div class="obj-card__icon-wrap">♻️</div>
        <h3 class="obj-card__title">Reciclaje</h3>
        <p class="obj-card__desc">Promover el reciclaje como hábito diario mediante guías sencillas y campañas que hagan al reciclaje accesible para todos.</p>
      </article>
      <article class="obj-card obj-card--emerald">
        <div class="obj-card__stripe"></div>
        <div class="obj-card__icon-wrap">🌳</div>
        <h3 class="obj-card__title">Cuidado del entorno</h3>
        <p class="obj-card__desc">Incentivar acciones concretas como la limpieza de espacios públicos, la protección de zonas naturales y el uso responsable de recursos.</p>
      </article>
      <article class="obj-card obj-card--teal">
        <div class="obj-card__stripe"></div>
        <div class="obj-card__icon-wrap">📚</div>
        <h3 class="obj-card__title">Educación ambiental</h3>
        <p class="obj-card__desc">Ofrecer recursos educativos digitales que faciliten el aprendizaje sobre los ecosistemas, la sostenibilidad y el impacto humano en el planeta.</p>
      </article>
    </div>
  </div>
</section>

<!-- ─── SABÍAS QUE (nuevo) ─── -->
<section class="sabias-que">
  <div class="container">
    <div class="sabias-que__header">
      <span class="section-tag">Curiosidades</span>
      <h2 class="section-title">¿Sabías <em style="color:var(--amber)">que?</em></h2>
    </div>
    <div class="sabias-que__slider">
      <button class="slider-btn prev" aria-label="Anterior">‹</button>
      <div class="slider-track-container">
        <ul class="slider-track" id="facts-track">
          <!-- Los items se inyectarán con JS -->
        </ul>
      </div>
      <button class="slider-btn next" aria-label="Siguiente">›</button>
    </div>
  </div>
</section>

<!-- ─── IMPACTO AMBIENTAL (nuevo) ─── -->
<section class="impacto">
  <div class="container">
    <div class="impacto__grid">
      <!-- Visual – ring chart -->
      <div class="impacto__visual">
        <div class="impacto__ring-wrap">
          <svg class="impacto__ring-svg" viewBox="0 0 340 340">
            <defs>
              <linearGradient id="ringGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#38a66f"/>
                <stop offset="100%" stop-color="#5cc490"/>
              </linearGradient>
              <linearGradient id="ringGrad2" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#14b8a6"/>
                <stop offset="100%" stop-color="#2dd4bf"/>
              </linearGradient>
              <linearGradient id="ringGrad3" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="#10b981"/>
                <stop offset="100%" stop-color="#34d399"/>
              </linearGradient>
            </defs>
            <!-- Background ring -->
            <circle cx="170" cy="170" r="130" fill="none" stroke="#e8f6ee" stroke-width="28"/>
            <!-- Segments (stroke-dasharray / offset trick) -->
            <!-- Segment 1: 45% of circumference = 367 of 816 -->
            <circle cx="170" cy="170" r="130" fill="none" stroke="url(#ringGrad1)" stroke-width="28"
                    stroke-dasharray="367 449" stroke-dashoffset="0" stroke-linecap="round"/>
            <!-- Segment 2: 30% = 245 -->
            <circle cx="170" cy="170" r="130" fill="none" stroke="url(#ringGrad2)" stroke-width="28"
                    stroke-dasharray="245 571" stroke-dashoffset="-367" stroke-linecap="round"/>
            <!-- Segment 3: 25% = 204 -->
            <circle cx="170" cy="170" r="130" fill="none" stroke="url(#ringGrad3)" stroke-width="28"
                    stroke-dasharray="204 612" stroke-dashoffset="-612" stroke-linecap="round"/>
          </svg>
          <div class="impacto__ring-center">
            <span class="big-num">72%</span>
            <span class="big-label">Reducción posible</span>
          </div>
        </div>
        <!-- Leyenda que explica los segmentos del gráfico de impacto. -->
        <div class="impacto__legend">
          <div class="impacto__legend-item">
            <span class="impacto__legend-dot" style="background:var(--green-500)"></span>
            <span>Residuos reciclables (45%)</span>
          </div>
          <div class="impacto__legend-item">
            <span class="impacto__legend-dot" style="background:var(--teal)"></span>
            <span>Energía renovable (30%)</span>
          </div>
          <div class="impacto__legend-item">
            <span class="impacto__legend-dot" style="background:var(--emerald)"></span>
            <span>Agua reutilizable (25%)</span>
          </div>
        </div>
      </div>

      <!-- Texto explicativo con datos y acciones para reducir el impacto. -->
      <div class="impacto__text">
        <span class="section-tag">El problema</span>
        <h2 class="section-title">El impacto<br/><em>ambiental</em></h2>
        <p>Cada año, millones de toneladas de residuos terminan en los rellenos sanitarios y los océanos. Sin embargo, una gran parte de ese impacto puede reducirse con acciones sencillas y conscientes.</p>
        <ul class="impacto__list">
          <li>
            <span class="check"><svg viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
            El 45% de los residuos domésticos son reciclables con clasificación correcta.
          </li>
          <li>
            <span class="check"><svg viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
            Reducir el consumo de plástico puede salvar más de 8 millones de toneladas anuales en el planeta.
          </li>
          <li>
            <span class="check"><svg viewBox="0 0 12 12" fill="none"><path d="M2 6l3 3 5-5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
            Las zonas verdes urbanas mejoran la calidad del aire y el bienestar comunitario.
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- ─── CÓMO AYUDAR (nuevo) ─── -->
<section class="como-ayudar">
  <div class="container">
    <div class="como-ayudar__header">
      <span class="section-tag">Tu papel</span>
      <h2 class="section-title">¿Cómo puedes<br/><em>ayudar?</em></h2>
      <p>No se necesitan grandes gestos. Tres pasos sencillas pueden marcar la diferencia en tu comunidad y en el planeta.</p>
    </div>
    <div class="steps">
      <div class="step">
        <div class="step__num-wrap">
          <div class="step__num-bg"></div>
          <span class="step__num">1</span>
        </div>
        <span class="step__icon">🔍</span>
        <h3 class="step__title">Infórmate</h3>
        <p class="step__desc">Conoce los recursos educativos que Ecopatrulla pone a tu disposición para entender mejor el medio ambiente y tu impacto en él.</p>
      </div>
      <div class="step">
        <div class="step__num-wrap">
          <div class="step__num-bg"></div>
          <span class="step__num">2</span>
        </div>
        <span class="step__icon">🤝</span>
        <h3 class="step__title">Participa</h3>
        <p class="step__desc">Suma a las actividades ecológicas: jornadas de reciclaje, limpieza de zonas verdes o campañas educativas en tu zona.</p>
      </div>
      <div class="step">
        <div class="step__num-wrap">
          <div class="step__num-bg"></div>
          <span class="step__num">3</span>
        </div>
        <span class="step__icon">💚</span>
        <h3 class="step__title">Actúa</h3>
        <p class="step__desc">Implementa hábitos sostenibles en tu hogar y comparte el mensaje con tu comunidad. El cambio empieza con cada uno de nosotros.</p>
      </div>
    </div>
  </div>
</section>

<!-- ─── BANDA DE ACCIÓN: enlaces principales para continuar explorando ─── -->
<section class="cta-band">
  <div class="cta-band__bg"></div>
  <div class="cta-band__blob1"></div>
  <div class="cta-band__blob2"></div>
  <div class="container cta-band__inner">
    <h2 class="cta-band__title">Informa.<br/>Motiva.<br/><em style="color:var(--green-300); font-style:italic;">Actúa.</em></h2>
    <p class="cta-band__text">Ecopatrulla existe para que la información ambiental llegue a todos. Descubre actividades que puedes realizar hoy mismo y recursos que te ayudarán a entender mejor nuestro planeta.</p>
    <div class="cta-band__links">
      <a href="actividades.php" class="btn btn--light">
        Ver actividades
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      </a>
      <a href="recursos.php" class="btn btn--outline-light">Recursos digitales</a>
    </div>
  </div>
</section>

<!-- ─── MENSAJE FINAL (nuevo) ─── -->
<section class="mensaje-final">
  <div class="mensaje-final__deco">"</div>
  <div class="container mensaje-final__content">
    <span class="section-tag">Reflexión</span>
    <p class="mensaje-final__quote">
      La naturaleza no es un recurso ilimitado;<br/>es un regalo que debemos <em>cuidar entre todos.</em>
    </p>
    <p class="mensaje-final__sub">
      Cada pequeña decisión que tomes hoy contribuye a un futuro más verde. Sé parte de la solución y conviértete en un verdadero Ecopatrulla.
    </p>
    <div class="mensaje-final__actions">
      <a href="calculadora.php" class="btn btn--primary">
        Unirme ahora
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      </a>
      <a href="recursos.php" class="btn btn--secondary">Explorar recursos</a>
    </div>
  </div>
</section>

<!-- ─── NEWSLETTER (nuevo) ─── -->
<section class="newsletter">
  <div class="container">
    <div class="newsletter__inner">
      <div class="newsletter__text">
        <h3>Únete a la Ecopatrulla</h3>
        <p>Recibe consejos semanales, noticias sobre eventos y guías exclusivas para vivir de forma más sostenible.</p>
      </div>
      <form class="newsletter__form" onsubmit="event.preventDefault(); alert('¡Gracias por suscribirte! 🌿');">
        <input type="email" placeholder="Tu correo electrónico" required />
        <button type="submit" class="btn btn--primary">Suscribirse</button>
      </form>
    </div>
  </div>
</section>

<!-- ─── PIE DE PÁGINA ─── -->
<!-- Separador ondulado entre el contenido y el pie de página. -->
<div class="footer-wave">
  <svg viewBox="0 0 1440 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0,40 C240,80 480,0 720,40 C960,80 1200,0 1440,40 L1440,80 L0,80 Z" fill="#0f2518"/>
  </svg>
</div>
<footer class="footer">
  <div class="container">
    <div class="footer__grid">
      <!-- Identidad visual y descripción breve del proyecto. -->
      <div class="footer__brand-col">
        <a href="index.php" class="logotipo">
          <div class="logotipo__icono">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 22V13" stroke="white" stroke-width="2" stroke-linecap="round"/>
              <path d="M12 13C12 13 8 12 6 9C4.5 6.5 5.5 3 8 2C9.5 1.3 11.2 1.8 12 3C12.8 1.8 14.5 1.3 16 2C18.5 3 19.5 6.5 18 9C16 12 12 13 12 13Z" fill="white" opacity="0.9"/>
            </svg>
          </div>
          <span class="logotipo__texto">Ecopatrulla</span>
        </a>
        <p>Una plataforma educativa digital dedicada a la conciencia ambiental y al cambio sostenible en nuestras comunidades.</p>
      </div>
      <!-- Explorar -->
      <div class="footer__col">
        <h4>Explorar</h4>
        <ul>
          <li><a href="index.php">Inicio</a></li>
          <li><a href="actividades.php">Actividades</a></li>
          <li><a href="recursos.php">Recursos Digitales</a></li>
        </ul>
      </div>
      <!-- Actividades -->
      <div class="footer__col">
        <h4>Actividades</h4>
        <ul>
          <li><a href="actividades.php">Jornadas de Reciclaje</a></li>
          <li><a href="actividades.php">Limpieza de Zonas Verdes</a></li>
          <li><a href="actividades.php">Campañas Educativas</a></li>
          <li><a href="actividades.php">Jardines Urbanos</a></li>
        </ul>
      </div>
      <!-- Recursos -->
      <div class="footer__col">
        <h4>Recursos</h4>
        <ul>
          <li><a href="recursos.php">Videos educativos</a></li>
          <li><a href="recursos.php">Guías interactivas</a></li>
          <li><a href="recursos.php">Infografías</a></li>
          <li><a href="recursos.php">Libros digitales</a></li>
        </ul>
      </div>
    </div>
    <!-- Bottom -->
    <div class="footer__bottom">
      <p class="footer__quote">"La naturaleza no es un recurso ilimitado; es un regalo que debemos cuidar entre todos."</p>
      <p class="footer__copy">© 2025 Ecopatrulla · Proyecto educativo ambiental</p>
    </div>
  </div>
</footer>

<script src="nav.js"></script>
<script src="main.js"></script>
<script src="experience.js"></script>
</body>
</html>
