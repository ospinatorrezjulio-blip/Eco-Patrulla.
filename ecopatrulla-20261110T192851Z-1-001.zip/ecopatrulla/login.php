<?php
declare(strict_types=1);

session_start();
include "conexion.php";

// Guardar aquí el mensaje que se mostrará si los datos de acceso son incorrectos.
$error = "";

// Procesar el formulario únicamente cuando el usuario lo envía por POST.
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Aceptar tanto el nombre de usuario como el correo electrónico para iniciar sesión.
    $usuario = trim($_POST["usuario"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($usuario === "" || $password === "") {
        $error = "Ingresa tu usuario y contraseña.";
    } else {
        // Buscar una sola cuenta mediante una consulta preparada para evitar inyección SQL.
        $sql = "SELECT id, nombre, usuario, password, rol FROM usuarios WHERE usuario = ? OR correo = ? LIMIT 1";
        $stmt = $conexion->prepare($sql);

        if (!$stmt) {
            $error = "No se pudo iniciar sesión. Inténtalo nuevamente.";
        } else {
            $stmt->bind_param("ss", $usuario, $usuario);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $cuenta = $resultado->fetch_assoc();

            // Comparar la contraseña escrita con el hash almacenado en la base de datos.
            if ($cuenta && password_verify($password, $cuenta["password"])) {
                // Regenerar el identificador para evitar fijación de sesión después del login.
                session_regenerate_id(true);
                $_SESSION["usuario_id"] = (int) $cuenta["id"];
                $_SESSION["usuario_nombre"] = $cuenta["nombre"];
                $_SESSION["usuario"] = $cuenta["usuario"];
                $_SESSION["rol"] = $cuenta["rol"];
               $stmt->close();
$conexion->close();

// Si es administrador, entrar al CRUD.
if ($cuenta["rol"] === "administrador") {
    header("Location: crud/usuarios.php");
    exit();
}

// Si es estudiante, entrar al inicio.
header("Location: index.php");
exit();
            }

            // Usar un mensaje general para no revelar si falló el usuario o la contraseña.
            $error = "El usuario o la contraseña no son correctos.";
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión - Ecopatrulla</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="extra.css">
    <style>

        .login-page {
            min-height: 100vh; /* Cambia 150vh a 100vh */
            display: grid;
            place-items: center; /* Centra tanto en horizontal como en vertical */
            padding: calc(var(--nav-h) + 40px) 20px 40px;
            background: linear-gradient(145deg, var(--green-950), #173a29 55%, #0d2116);
            box-sizing: border-box; /* Asegura que el padding no rompa el alto */
        }
        .login-content {
            width: min(560px, 100%);
            display: flex;
            flex-direction: column;
            gap: 24px;
        }
        .login-slogan {
            text-align: center;
            color: #fff;
            animation: loginSloganFloat 4.5s ease-in-out infinite;
        }
        .login-slogan span {
            display: block;
            margin-bottom: 8px;
            color: var(--green-300);
            font-size: .78rem;
            font-weight: 600;
            letter-spacing: 2.5px;
            text-transform: uppercase;
        }
        .login-slogan strong {
            display: block;
            font-family: var(--font-display);
            font-size: clamp(2rem, 6vw, 3.2rem);
            line-height: 1.1;
        }
        @keyframes loginSloganFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-7px); }
        }
        .login-card {
            width: min(460px, 100%);
            margin: 0 auto;
            padding: 45px;
            color: #fff;
            background: rgba(255,255,255,.1);
            border: 1px solid rgba(255,255,255,.16);
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow-xl);
            backdrop-filter: blur(18px);
        }
        .login-card h1 {
            margin-bottom: 10px;
            font-family: var(--font-display);
            font-size: 2.5rem;
            text-align: center;
        }
        .login-card > p {
            margin-bottom: 28px;
            color: rgba(255,255,255,.7);
            text-align: center;
        }
        .login-field { margin-bottom: 18px; }
        .login-field label {
            display: block;
            margin-bottom: 7px;
            font-weight: 600;
        }
        .login-field input {
            width: 100%;
            padding: 13px 15px;
            color: var(--green-900);
            background: #fff;
            border: 1px solid transparent;
            border-radius: var(--radius-sm);
            font: inherit;
        }
        .login-field input:focus {
            outline: 2px solid var(--green-300);
            outline-offset: 2px;
        }
        .login-card .btn { width: 100%; margin-top: 8px; }
        .login-error {
            margin-bottom: 18px;
            padding: 12px 14px;
            color: #ffe4e6;
            background: rgba(190, 24, 93, .25);
            border: 1px solid rgba(253, 164, 175, .4);
            border-radius: var(--radius-sm);
            text-align: center;
        }
        .login-register {
            margin-top: 24px;
            color: rgba(255,255,255,.7);
            text-align: center;
        }
        .login-register a { color: var(--green-300); font-weight: 600; }
        @media (prefers-reduced-motion: reduce) {
            .login-slogan { animation: none; }
        }
    </style>
</head>
<body>
<header class="header">
    <div class="header__inner">
        <a href="index.php" class="logo">
            <div class="logo__icon"><span aria-hidden="true"><div class="logo__icon">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 22V13" stroke="white" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 13C12 13 8 12 6 9C4.5 6.5 5.5 3 8 2C9.5 1.3 11.2 1.8 12 3C12.8 1.8 14.5 1.3 16 2C18.5 3 19.5 6.5 18 9C16 12 12 13 12 13Z" fill="white" opacity="0.9"/>
          <path d="M12 16C12 16 9 15.5 7.5 14C6 12.5 6.5 10 8 9.5C9 9.1 10.2 9.5 11 10.2C11.4 9.5 12.6 9.1 13.6 9.5C15.1 10 15.6 12.5 14.1 14C12.6 15.5 12 16 12 16Z" fill="white"/>
        </svg>
      </div></span></div>
            <span class="logo__text">Ecopatrulla</span>
        </a>
        <a href="registro.php" class="header__cta">Crear cuenta</a>
    </div>
</header>

<main class="login-page">
    <div class="login-content">
        <div class="login-slogan" aria-label="El planeta necesita tu ayuda">
            <span>Conciencia ambiental para todos</span>
            <strong>El planeta necesita tu ayuda.</strong>
        </div>

        <section class="login-card" aria-labelledby="login-title">
        <h1 id="login-title">Iniciar sesión</h1>
        <p>Accede a tu cuenta de Ecopatrulla.</p>

        <?php if ($error !== ""): ?>
            <div class="login-error" role="alert">
                <?php echo htmlspecialchars($error, ENT_QUOTES, "UTF-8"); ?>
            </div>
        <?php endif; ?>

        <form method="post" action="login.php">
           <center> <div class="login-field">
                <label for="usuario">Usuario o correo</label>
                <input id="usuario" name="usuario" type="text" autocomplete="username" required>
            </div>

            <div class="login-field">
                <label for="password">Contraseña</label>
                <input id="password" name="password" type="password" autocomplete="current-password" required>
            </div></center>

            <button type="submit" class="btn btn--primary">Iniciar sesión</button>
        </form>

        <p class="login-register">¿Aún no tienes cuenta? <a href="registro.php">Regístrate</a></p>
        </section>
    </div>
</main>

<script src="nav.js"></script>
<script src="main.js"></script>
</body>
</html>
