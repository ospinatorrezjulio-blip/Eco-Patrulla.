<?php
declare(strict_types=1);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ecopatrulla – Recursos Digitales</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;1,600&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="styles.css" />
  <link rel="stylesheet" href="extra.css" />
</head>
<body>

<!-- ─── ENCABEZADO: identidad, tema y navegación principal ─── -->
<header class="header">
  <div class="header__inner">
    <a href="index.php" class="logo">
      <div class="logo__icon">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 22V13" stroke="white" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 13C12 13 8 12 6 9C4.5 6.5 5.5 3 8 2C9.5 1.3 11.2 1.8 12 3C12.8 1.8 14.5 1.3 16 2C18.5 3 19.5 6.5 18 9C16 12 12 13 12 13Z" fill="white" opacity="0.9"/>
          <path d="M12 16C12 16 9 15.5 7.5 14C6 12.5 6.5 10 8 9.5C9 9.1 10.2 9.5 11 10.2C11.4 9.5 12.6 9.1 13.6 9.5C15.1 10 15.6 12.5 14.1 14C12.6 15.5 12 16 12 16Z" fill="white"/>
        </svg>
      </div>
      <span class="logo__text">Ecopatrulla</span>
    </a>
    
    <button class="theme-toggle" aria-label="Cambiar tema">
      <svg class="icono-sol" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
      <svg class="icono-luna" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
    </button>

    <button class="nav-toggle" aria-label="Abrir menú">
      <span></span><span></span><span></span>
    </button>
    <nav class="nav">
      <div class="nav__pill"></div>
      <a href="index.php"       class="nav__link">Inicio</a>
      <a href="actividades.php" class="nav__link">Actividades</a>
      <a href="recursos.php"    class="nav__link nav__link--active">Recursos</a>
      
    </nav>
    <a href="login.php" class="header__cta">
      Participa
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
  </div>
</header>

<!-- ─── PORTADA: presentación de los recursos digitales ─── -->
<section class="page-hero page-hero--recursos">
  <div class="page-hero__bg"></div>
  <div class="page-hero__grain"></div>
  <span class="leaf leaf--1">🍃</span>
  <span class="leaf leaf--2">🍂</span>
  <span class="leaf leaf--4">🌱</span>
  <span class="leaf leaf--5">🌿</span>
  <div class="container page-hero__content">
    <span class="section-tag section-tag--light">Aprende</span>
    <h1 class="page-hero__title">Recursos<br/><em>digitales</em></h1>
    <p class="page-hero__desc">Herramientas educativas diseñadas para que el conocimiento ambiental esté al alcance de todos.</p>
  </div>
</section>

<!-- ─── FRANJA DE FILTROS: filtro.js controla los botones por categoría ─── -->
<section class="filter-strip">
  <div class="container">
    <div class="filter-strip__inner">
      <span class="filter-strip__label">Categoría</span>
      <div class="filter-strip__buttons">
        <div class="filter-pill"></div>
        <button class="filter-btn filter-btn--active" data-filter="all">Todos</button>
        <button class="filter-btn" data-filter="video">Videos</button>
        <button class="filter-btn" data-filter="guia">Guías</button>
        <button class="filter-btn" data-filter="infografico">Infografías</button>
      </div>
    </div>
  </div>
</section>

<!-- ─── RECURSOS: tarjetas clasificadas mediante el atributo data-type ─── -->
<section class="recursos">
  <div class="container">
    <div class="recursos__grid">

      <!-- Recurso audiovisual de la categoría video. -->
      <a class="res-card res-card--video-link"
   data-type="video"
   href="https://www.youtube.com/watch?v=zDj9BsIoX64"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Ver video sobre cómo reciclar correctamente">

  <div class="res-card__media res-card__media--video">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">🎬</span>
      <span class="res-card__play">
        <svg viewBox="0 0 24 24" fill="currentColor">
          <polygon points="5,3 19,12 5,21"/>
        </svg>
      </span>
    </div>
    <span class="res-card__badge">Video</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Video educativo</span>
    <h3 class="res-card__title">Cómo reciclar correctamente</h3>
    <p class="res-card__desc">
      Aprende cómo separar correctamente los residuos y clasificar los materiales reciclables.
    </p>
  </div>

</a>
      <!-- Segundo recurso audiovisual de la categoría video. -->
      <a class="res-card res-card--video-link"
   data-type="video"
   href="https://www.youtube.com/watch?v=cSQhPy1_XRA"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Ver video sobre el cuidado de los océanos">

  <div class="res-card__media res-card__media--video">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">🌊</span>
      <span class="res-card__play">
        <svg viewBox="0 0 24 24" fill="currentColor">
          <polygon points="5,3 19,12 5,21"/>
        </svg>
      </span>
    </div>
    <span class="res-card__badge">Video</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Video educativo</span>
    <h3 class="res-card__title">Los océanos: ecosistemas vitales</h3>
    <p class="res-card__desc">
      Descubre por qué los océanos son fundamentales para la vida en la Tierra y cómo la contaminación los afecta.
    </p>
  </div>

</a>

      <!-- Guía práctica identificada con data-type="guia". -->
      <a class="res-card res-card--guia-link"
   data-type="guia"
   href="https://www.epa.gov/recycle"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Consultar guía sobre clasificación de residuos">

  <div class="res-card__media res-card__media--guia">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">📋</span>
    </div>
    <span class="res-card__badge">Guía</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Guía educativa</span>
    <h3 class="res-card__title">Clasificación de residuos</h3>
    <p class="res-card__desc">
      Consulta información sobre cómo separar los residuos, reciclar correctamente y reducir la basura.
    </p>
  </div>

</a>
      <!-- Infografía identificada con data-type="infografico". -->
    <a class="res-card res-card--infografico-link"
   data-type="infografico"
   href="https://www.fundacionaquae.org/wiki/ciclo-del-agua/"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Consultar infografía sobre el ciclo del agua">

  <div class="res-card__media res-card__media--infografico">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">📊</span>
    </div>
    <span class="res-card__badge">Infografía</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Recurso visual</span>
    <h3 class="res-card__title">El ciclo del agua en la naturaleza</h3>
    <p class="res-card__desc">
      Aprende cómo el agua circula en la naturaleza mediante la evaporación, la condensación y la precipitación, y por qué debemos conservarla.
    </p>
  </div>

</a>
      <!-- Tercer recurso audiovisual de la categoría video. -->
     <a class="res-card res-card--video-link"
   data-type="video"
   href="https://youtu.be/73Ke7MMtMMc"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Ver tutorial sobre compostaje en casa">

  <div class="res-card__media res-card__media--video">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">🌿</span>
      <span class="res-card__play">
        <svg viewBox="0 0 24 24" fill="currentColor">
          <polygon points="5,3 19,12 5,21"/>
        </svg>
      </span>
    </div>
    <span class="res-card__badge">Video</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Tutorial práctico</span>
    <h3 class="res-card__title">Compostaje en casa</h3>
    <p class="res-card__desc">
      Aprende cómo transformar los residuos orgánicos en abono natural para las plantas y los jardines.
    </p>
  </div>

</a>

      <!-- Segunda guía práctica de la biblioteca. -->
     
<a class="res-card res-card--guia-link"
   data-type="guia"
   href="https://www.unep.org/es"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Consultar consejos sobre hábitos verdes en el hogar">

  <div class="res-card__media res-card__media--guia">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">🌱</span>
    </div>
    <span class="res-card__badge">Guía</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Guía educativa</span>
    <h3 class="res-card__title">Hábitos verdes en el hogar</h3>
    <p class="res-card__desc">
      Descubre consejos para ahorrar agua y energía, reducir los residuos y adoptar hábitos más sostenibles en casa.
    </p>
  </div>

</a>

      <!-- Segunda infografía de la biblioteca. -->
     
<a class="res-card res-card--infografico-link"
   data-type="infografico"
   href="https://www.unep.org/es/plastics"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Consultar información sobre el impacto del plástico en el planeta">

  <div class="res-card__media res-card__media--infografico">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">🌏</span>
    </div>
    <span class="res-card__badge">Infografía</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Recurso visual</span>
    <h3 class="res-card__title">Impacto del plástico en el planeta</h3>
    <p class="res-card__desc">
      Conoce cómo la contaminación por plástico afecta los ecosistemas y descubre alternativas para reducir su uso.
    </p>
  </div>

</a>


      <!-- Tercera guía práctica de la biblioteca. -->
    
<a class="res-card res-card--guia-link"
   data-type="guia"
   href="https://www.humboldt.org.co/"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Consultar guía sobre biodiversidad local">

  <div class="res-card__media res-card__media--guia">
    <div class="res-card__thumb">
      <span class="res-card__thumb-icon">🦋</span>
    </div>
    <span class="res-card__badge">Guía</span>
  </div>

  <div class="res-card__info">
    <span class="res-card__duration">Recurso educativo</span>
    <h3 class="res-card__title">Biodiversidad local</h3>
    <p class="res-card__desc">
      Conoce la diversidad de fauna y flora de Colombia y aprende cómo contribuir a la conservación de las especies y sus hábitats.
    </p>
  </div>

</a>

    </div>
  </div>
</section>

<!-- ─── PIE DE PÁGINA: enlaces secundarios y datos del proyecto ─── -->
<div class="footer-wave">
  <svg viewBox="0 0 1440 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0,40 C240,80 480,0 720,40 C960,80 1200,0 1440,40 L1440,80 L0,80 Z" fill="#0f2518"/>
  </svg>
</div>
<footer class="footer">
  <div class="container">
    <div class="footer__grid">
      <div class="footer__brand-col">
        <a href="index.php" class="logotipo">
          <div class="logotipo__icono">
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 22V13" stroke="white" stroke-width="2" stroke-linecap="round"/>
              <path d="M12 13C12 13 8 12 6 9C4.5 6.5 5.5 3 8 2C9.5 1.3 11.2 1.8 12 3C12.8 1.8 14.5 1.3 16 2C18.5 3 19.5 6.5 18 9C16 12 12 13 12 13Z" fill="white" opacity="0.9"/>
            </svg>
          </div>
          <span class="logotipo__texto">Ecopatrulla</span>
        </a>
        <p>Una plataforma educativa digital dedicada a la conciencia ambiental y al cambio sostenible en nuestras comunidades.</p>
      </div>
      <div class="footer__col">
        <h4>Explorar</h4>
        <ul>
          <li><a href="index.php">Inicio</a></li>
          <li><a href="actividades.php">Actividades</a></li>
          <li><a href="recursos.php">Recursos Digitales</a></li>
        </ul>
      </div>
      <div class="footer__col">
        <h4>Actividades</h4>
        <ul>
          <li><a href="actividades.php">Jornadas de Reciclaje</a></li>
          <li><a href="actividades.php">Limpieza de Zonas Verdes</a></li>
          <li><a href="actividades.php">Campañas Educativas</a></li>
          <li><a href="actividades.php">Jardines Urbanos</a></li>
        </ul>
      </div>
      <div class="footer__col">
        <h4>Recursos</h4>
        <ul>
          <li><a href="recursos.php">Videos educativos</a></li>
          <li><a href="recursos.php">Guías interactivas</a></li>
          <li><a href="recursos.php">Infografías</a></li>
          <li><a href="recursos.php">Libros digitales</a></li>
        </ul>
      </div>
    </div>
    <div class="footer__bottom">
      <p class="footer__quote">"La naturaleza no es un recurso ilimitado; es un regalo que debemos cuidar entre todos."</p>
      <p class="footer__copy">© 2025 Ecopatrulla · Proyecto educativo ambiental</p>
    </div>
  </div>
</footer>

<script src="nav.js"></script>
<script src="main.js"></script>
<script src="filtro.js?v=2"></script>
<script src="experience.js"></script>
</body>
</html>
