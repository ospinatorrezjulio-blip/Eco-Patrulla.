/* ─── nav.js v2: comportamiento compartido por todas las páginas ─── */
(function () {
  // Obtener los elementos comunes del encabezado; algunas páginas pueden no tenerlos.
  const header = document.querySelector('.header');
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');

  /* ══════ MENÚ HAMBURGUESA Y ACCESIBILIDAD ══════ */
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      if (header) header.classList.toggle('menu-open', isOpen);
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.setAttribute('aria-label', isOpen ? 'Cerrar menú' : 'Abrir menú');
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });
    nav.querySelectorAll('.nav__link').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('open');
        if (header) header.classList.remove('menu-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Abrir menú');
        document.body.style.overflow = '';
      });
    });

    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && nav.classList.contains('open')) {
        nav.classList.remove('open');
        if (header) header.classList.remove('menu-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Abrir menú');
        document.body.style.overflow = '';
        toggle.focus();
      }
    });
  }

  // Marcar como activa la opción cuyo enlace coincide con la página actual.
  const currentPage = window.location.pathname.split('/').pop() || 'index.php';
  if (nav) {
    nav.querySelectorAll('.nav__link').forEach(link => {
      const linkPage = link.getAttribute('href').split('/').pop();
      const isCurrent = linkPage === currentPage;
      link.classList.toggle('nav__link--active', isCurrent);
      if (isCurrent) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
  }

  /* ══════ SOMBRA DEL ENCABEZADO AL DESPLAZARSE ══════ */
  window.addEventListener('scroll', () => {
    if (header) header.classList.toggle('scrolled', window.scrollY > 30);
  }, { passive: true });

  /* ══════ INDICADOR DESLIZANTE DE NAVEGACIÓN (escritorio) ══════ */
  (function initPill() {
    const pill = document.querySelector('.nav__pill');
    const links = document.querySelectorAll('.nav__link');
    if (!pill || !links.length) return;

    function movePill(target) {
      const navEl = target.parentElement;
      const rect   = target.getBoundingClientRect();
      const navRect = navEl.getBoundingClientRect();
      pill.style.left  = (rect.left - navRect.left) + 'px';
      pill.style.width = rect.width + 'px';
    }

    // Colocar el indicador detrás del enlace activo al cargar la página.
    const active = document.querySelector('.nav__link--active');
    if (active) movePill(active);

    links.forEach(link => {
      link.addEventListener('mouseenter', () => movePill(link));
      link.addEventListener('mouseleave', () => {
        const act = document.querySelector('.nav__link--active');
        if (act) movePill(act);
      });
    });

    window.addEventListener('resize', () => {
      const act = document.querySelector('.nav__link--active');
      if (act) movePill(act);
    });
  })();

  /* ══════ EFECTO DE ONDA EN BOTONES ══════ */
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('mousedown', e => {
      const rect = btn.getBoundingClientRect();
      btn.style.setProperty('--x', ((e.clientX - rect.left) / rect.width  * 100) + '%');
      btn.style.setProperty('--y', ((e.clientY - rect.top)  / rect.height * 100) + '%');
    });
  });

  /* ══════ REVELADO AL DESPLAZARSE ══════ */
  const revealMap = {
    // Cada selector se asocia con la dirección desde la que aparecerá.
    '.about__grid'            : 'up',
    '.about__badge'           : 'scale',
    '.objetivos__grid .obj-card' : 'up',
    '.act-card'               : 'up',
    '.cta-band__inner'        : 'up',
    '.res-card'               : 'up',
    '.impacto__visual'        : 'left',
    '.impacto__text'          : 'right',
    '.step'                   : 'up',
    '.stat'                   : 'up',
    '.mensaje-final__content' : 'up',
    '.page-hero__content'     : 'up'
  };

  Object.entries(revealMap).forEach(([selector, dir]) => {
    document.querySelectorAll(selector).forEach((el, i) => {
      el.classList.add('reveal', 'reveal--' + dir);
      el.style.transitionDelay = (i % 4) * 0.1 + 's';
    });
  });

  // Activar la animación únicamente cuando cada elemento entra en pantalla.
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  /* ══════ CONTADORES ANIMADOS ══════ */
  function animateCounter(el, target, suffix, duration) {
    // Interpolar el número desde cero hasta su valor final con una curva suave.
    const start = performance.now();
    function step(now) {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // Curva cúbica de desaceleración para que el contador termine suavemente.
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(eased * target);
      el.innerHTML = current.toLocaleString() + '<span class="suffix">' + suffix + '</span>';
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.dataset.counted) {
        entry.target.dataset.counted = 'true';
        const target = parseInt(entry.target.dataset.target, 10);
        const suffix = entry.target.dataset.suffix || '';
        animateCounter(entry.target, target, suffix, 1400);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('.stat__number[data-target]').forEach(el => counterObserver.observe(el));

  /* ══════ PARALAJE LIGERO DE LA PORTADA ══════ */
  const heroGrain = document.querySelector('.hero__grain');
  if (heroGrain) {
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      if (y < window.innerHeight) {
        heroGrain.style.transform = 'translateY(' + (y * 0.08) + 'px)';
        heroGrain.style.opacity  = 0.25 - (y / window.innerHeight) * 0.15;
      }
    }, { passive: true });
  }
})();
