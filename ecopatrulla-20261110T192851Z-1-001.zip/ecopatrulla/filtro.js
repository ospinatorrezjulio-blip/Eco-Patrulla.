/* ─── filtro.js v2: filtro de recursos e indicador deslizante ─── */
(function () {
  const buttons = document.querySelectorAll('.filter-btn');
  const cards   = document.querySelectorAll('.res-card');
  const pill    = document.querySelector('.filter-pill');

  if (!buttons.length || !cards.length) return;

  /* ── Posicionar la cápsula sobre el botón seleccionado ── */
  function movePill(target) {
    if (!pill) return;
    const container = target.parentElement;
    const rect      = target.getBoundingClientRect();
    const cRect     = container.getBoundingClientRect();
    pill.style.left  = (rect.left - cRect.left) + 'px';
    pill.style.width = rect.width + 'px';
  }

  // Colocar inicialmente la cápsula sobre el filtro activo.
  const initActive = document.querySelector('.filter-btn--active');
  if (initActive) movePill(initActive);

  /* ── Lógica de filtrado de tarjetas ── */
  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      // Actualizar la clase visual del botón seleccionado.
      buttons.forEach(b => b.classList.remove('filter-btn--active'));
      btn.classList.add('filter-btn--active');
      // Mover la cápsula para acompañar al botón activo.
      movePill(btn);
      const filter = btn.dataset.filter;
      let idx = 0;
      cards.forEach(card => {
        if (filter === 'all' || card.dataset.type === filter) {
          card.classList.remove('hidden');
          card.classList.remove('visible');
          card.style.transitionDelay = (idx % 3) * 0.08 + 's';
          idx++;
          requestAnimationFrame(() => requestAnimationFrame(() => card.classList.add('visible')));
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });

  /* ── Recalcular la posición al cambiar el tamaño de ventana ── */
  window.addEventListener('resize', () => {
    const act = document.querySelector('.filter-btn--active');
    if (act) movePill(act);
  });
})();
