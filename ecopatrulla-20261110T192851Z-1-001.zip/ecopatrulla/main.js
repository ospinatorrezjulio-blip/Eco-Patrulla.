
/* ─── JS PRINCIPAL: funciones interactivas del sitio ─── */

// Inicializar solo cuando el HTML ya esté disponible.
document.addEventListener('DOMContentLoaded', () => {
  initDarkMode();
  initEcoReto();
  initSabiasQue();
  initCalculator();
});

/* ══════ MODO OSCURO ══════ */
function initDarkMode() {
  const toggle = document.querySelector('.theme-toggle');
  const body = document.body;
  
  // Recuperar la preferencia guardada para conservar el tema entre visitas.
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    body.classList.add('dark-mode');
  }

  if (toggle) {
    toggle.addEventListener('click', () => {
      body.classList.toggle('dark-mode');
      const isDark = body.classList.contains('dark-mode');
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });
  }
}

/* ══════ ECO RETO ══════ */
const retos = [
  { text: "Recoge 3 piezas de plástico en tu calle hoy.", icon: "🗑️" },
  { text: "Usa una botella reutilizable todo el día.", icon: "💧" },
  { text: "Apaga las luces de las habitaciones vacías.", icon: "💡" },
  { text: "Comparte un consejo ecológico en tus redes.", icon: "📱" },
  { text: "Camina o usa bici en lugar del auto para un trayecto corto.", icon: "🚲" },
  { text: "Separa tus residuos orgánicos hoy.", icon: "🍌" },
  { text: "Dúchate en menos de 5 minutos.", icon: "🚿" },
  { text: "Planta una semilla o riega una planta.", icon: "🌱" }
];

function initEcoReto() {
  const title = document.getElementById('reto-title');
  const desc = document.getElementById('reto-desc');
  const btn = document.getElementById('btn-nuevo-reto');
  const icon = document.querySelector('.eco-reto__icon');

  if (!title || !btn) return;

  function setReto() {
    const random = retos[Math.floor(Math.random() * retos.length)];
    // Actualizar el texto e icono del reto elegido al azar.
    desc.textContent = random.text;
    icon.textContent = random.icon;
    
    // Reiniciar la animación para que cada nuevo icono vuelva a flotar desde el inicio.
    icon.style.animation = 'none';
    icon.offsetHeight; /* Forzar un reflow para reiniciar la animación CSS. */
    icon.style.animation = 'float 6s ease-in-out infinite';
  }

  setReto();
  btn.addEventListener('click', setReto);
}

/* ══════ SABÍAS QUE SLIDER ══════ */
const facts = [
  { text: "Reciclar una lata de aluminio ahorra energía suficiente para ver TV por 3 horas.", icon: "📺" },
  { text: "Los árboles urbanos pueden bajar la temperatura del aire hasta 8°C.", icon: "🌳" },
  { text: "El 80% de la basura en los océanos proviene de tierra firme.", icon: "🌊" },
  { text: "Una sola pila de botón puede contaminar 600.000 litros de agua.", icon: "🔋" },
  { text: "Las abejas polinizan el 70% de los cultivos que comemos.", icon: "🐝" }
];

function initSabiasQue() {
  const track = document.getElementById('facts-track');
  const prevBtn = document.querySelector('.slider-btn.prev');
  const nextBtn = document.querySelector('.slider-btn.next');

  if (!track) return;

  // Crear las diapositivas dinámicamente a partir del arreglo de curiosidades.
  facts.forEach(fact => {
    const li = document.createElement('li');
    li.className = 'slide';
    li.innerHTML = `
      <span class="slide-icon">${fact.icon}</span>
      <p class="slide-text">${fact.text}</p>
    `;
    track.appendChild(li);
  });

  // Mantener el índice actual para mover el carrusel de forma circular.
  let currentIndex = 0;

  function updateSlider() {
    track.style.transform = `translateX(-${currentIndex * 100}%)`;
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      currentIndex = (currentIndex + 1) % facts.length;
      updateSlider();
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      currentIndex = (currentIndex - 1 + facts.length) % facts.length;
      updateSlider();
    });
  }
  
  window.addEventListener('resize', updateSlider);
}

/* ══════ CALCULADORA ══════ */
function initCalculator() {
  const form = document.getElementById('calc-form');
  const resultDiv = document.getElementById('calc-result');
  
  // Si no existe el formulario, no hacemos nada (estamos en otra página)
  if (!form || !resultDiv) return;

  const steps = document.querySelectorAll('.form-group');
  const nextBtn = document.getElementById('next-btn');
  const prevBtn = document.getElementById('prev-btn');
  const progressBar = document.getElementById('calc-progress');
  const scoreVal = document.getElementById('score-val');
  const resultMsg = document.getElementById('result-msg');
  const restartBtn = document.getElementById('restart-calc');
  
  let currentStep = 0;
  const totalSteps = steps.length;
  let answers = {};

  function updateView() {
    steps.forEach((step, idx) => {
      step.classList.toggle('active', idx === currentStep);
    });
    
    prevBtn.disabled = currentStep === 0;
    
    if (currentStep === totalSteps) {
        // Ocultar las preguntas y revelar el resultado final.
      form.style.display = 'none';
      resultDiv.hidden = false;
      resultDiv.style.display = 'flex';
      calculateResult();
    } else {
      resultDiv.hidden = true;
      nextBtn.textContent = currentStep === totalSteps - 1 ? 'Ver Resultado' : 'Siguiente';
      const progress = ((currentStep + 1) / totalSteps) * 100;
      if (progressBar) progressBar.style.width = `${progress}%`;
    }
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      // No permitir avanzar hasta seleccionar una respuesta del paso actual.
      const currentInputs = steps[currentStep].querySelectorAll('input[type="radio"]');
      let selected = false;
      currentInputs.forEach(input => {
        if (input.checked) {
          answers[input.name] = parseInt(input.value);
          selected = true;
        }
      });

      if (selected) {
        currentStep++;
        updateView();
      } else {
        alert('Por favor selecciona una opción para continuar.');
      }
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (currentStep > 0) {
        currentStep--;
        updateView();
      }
    });
  }

  if (restartBtn) {
    restartBtn.addEventListener('click', () => {
      currentStep = 0;
      answers = {};
      form.reset();
      form.style.display = '';
      resultDiv.hidden = true;
      resultDiv.style.display = 'none';
      updateView();
    });
  }

  function calculateResult() {
    // Convertir la suma de respuestas en una escala de uno a cinco planetas.
    let totalPoints = Object.values(answers).reduce((a, b) => a + b, 0);
    const minimumPoints = steps.length;
    const maximumPoints = steps.length * 4;
    const normalizedScore = (totalPoints - minimumPoints) / (maximumPoints - minimumPoints);
    const planets = (1 + normalizedScore * 4).toFixed(1);
    
    if (scoreVal) scoreVal.textContent = planets;
    
    if (resultMsg) {
      if (Number(planets) < 1.5) {
        resultMsg.textContent = "¡Excelente! Vives de manera muy sostenible. 🌱";
      } else if (Number(planets) < 3) {
        resultMsg.textContent = "Vas por buen camino, pero puedes mejorar algunos hábitos. 🌿";
      } else {
        resultMsg.textContent = "Tu estilo de vida consume muchos recursos. ¡Es hora de actuar! ⚠️";
      }
    }
  }
}
