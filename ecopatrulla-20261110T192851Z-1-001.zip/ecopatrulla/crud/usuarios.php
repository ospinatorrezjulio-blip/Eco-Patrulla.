<?php

include "../conexion.php";
include "../auth.php";

require_admin();

// Obtener los datos que se mostrarán en la tabla administrativa.
$sql = "SELECT id, nombre, usuario, correo, grupo FROM usuarios";

$resultado = $conexion->query($sql);

if (!$resultado) {
    // Informar si la consulta no pudo ejecutarse.
    die("No se pudieron consultar los usuarios: " . $conexion->error);
}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Usuarios - Ecopatrulla</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #e8f5e9;
            margin: 0;
            padding: 30px;
        }

        h1 {
            color: #1b5e20;
            text-align: center;
        }

        .contenedor {
            max-width: 1200px;
            margin: auto;
            background-color: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }

        .boton {
            display: inline-block;
            padding: 10px 15px;
            background-color: #2e7d32;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .boton:hover {
            background-color: #1b5e20;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background-color: #2e7d32;
            color: white;
            padding: 12px;
        }

        td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }

        tr:hover {
            background-color: #f1f8e9;
        }

        .editar {
            color: #1565c0;
            text-decoration: none;
            font-weight: bold;
        }

        .eliminar {
            color: #c62828;
            text-decoration: none;
            font-weight: bold;
        }

    </style>

</head>

<body>

    <div class="contenedor">

        <h1>Usuarios de Ecopatrulla</h1>

        <a href="../registro.php" class="boton">
            + Registrar usuario
        </a>

        <table>

            <tr>

                <th>ID</th>
                <th>Nombre</th>
                <th>Usuario</th>
                <th>Correo</th>
                <th>Grupo</th>
                <th>Acciones</th>

            </tr>

            <?php

            if ($resultado && $resultado->num_rows > 0) {

                while ($usuario = $resultado->fetch_assoc()) {

            ?>

                <tr>

                    <td>
                        <?php echo htmlspecialchars($usuario["id"]); ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars($usuario["nombre"]); ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars($usuario["usuario"]); ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars($usuario["correo"]); ?>
                    </td>

                    <td>
                        <?php echo htmlspecialchars($usuario["grupo"]); ?>
                    </td>

                    <td>

                        <a
                            href="editar_usuario.php?id=<?php echo urlencode($usuario["id"]); ?>"
                            class="editar">
                            Editar
                        </a>

                        &nbsp; | &nbsp;

                        <form action="eliminar_usuario.php" method="post" style="display:inline" onsubmit="return confirm('¿Seguro que quieres eliminar este usuario?');">
                            <input type="hidden" name="id" value="<?php echo (int) $usuario["id"]; ?>">
                            <button type="submit" class="eliminar">Eliminar</button>
                        </form>

                    </td>

                </tr>

            <?php

                }

            } else {

            ?>

                <tr>

                    <td colspan="6">
                        No hay usuarios registrados.
                    </td>

                </tr>

            <?php

            }

            ?>

        </table>

    </div>

</body>

</html>