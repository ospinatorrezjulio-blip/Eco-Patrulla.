<?php

include "../conexion.php";
include "../auth.php";

// Solo una sesión autenticada puede eliminar usuarios.
require_admin();

// Eliminar únicamente mediante POST para evitar borrados desde un enlace GET.
if ($_SERVER["REQUEST_METHOD"] !== "POST" || !isset($_POST["id"])) {
    die("No se encontró el usuario.");
}

$id = filter_var($_POST["id"], FILTER_VALIDATE_INT);

if ($id === false || $id < 1) {
    die("El identificador del usuario no es válido.");
}

// Validar el identificador antes de enviarlo a la consulta.
$sql = "DELETE FROM usuarios WHERE id = ?";

$stmt = $conexion->prepare($sql);

$stmt->bind_param("i", $id);

// Ejecutar la eliminación con parámetros preparados.
if ($stmt->execute()) {

    header("Location: usuarios.php?mensaje=eliminado");
    exit();

} else {

    echo "Error al eliminar el usuario: " . $stmt->error;
}

$stmt->close();
$conexion->close();

?>