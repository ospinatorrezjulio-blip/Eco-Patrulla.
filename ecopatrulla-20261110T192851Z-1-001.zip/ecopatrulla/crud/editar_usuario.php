<?php

include "../conexion.php";
include "../auth.php";

// Solo una sesión autenticada puede modificar registros.
require_admin();
// El formulario conserva el ID en la URL y también lo envía oculto.
$idRecibido = $_GET["id"] ?? $_POST["id"] ?? null;

if ($idRecibido === null) {
    die("No se encontró el usuario.");
}

$id = filter_var($idRecibido, FILTER_VALIDATE_INT);

if ($id === false || $id < 1) {
    die("El identificador del usuario no es válido.");
}

// Cargar los datos actuales para rellenar el formulario de edición.
$sql = "SELECT * FROM usuarios WHERE id = ?";
$stmt = $conexion->prepare($sql);

if (!$stmt) {
    die("No se pudo consultar el usuario: " . $conexion->error);
}
$stmt->bind_param("i", $id);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows == 0) {
    die("El usuario no existe.");
}

$usuario = $resultado->fetch_assoc();


// Si se envió el formulario, validar y actualizar los datos recibidos.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = trim($_POST["nombre"] ?? "");
    $documento = trim($_POST["documento"] ?? "");
    $usuario_nombre = trim($_POST["usuario"] ?? "");
    $correo = trim($_POST["correo"] ?? "");
    $celular = trim($_POST["celular"] ?? "");
    $grupo = trim($_POST["grupo"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "");
    $genero = trim($_POST["genero"] ?? "");

    if ($nombre === "" || $documento === "" || $usuario_nombre === "" ||
        !filter_var($correo, FILTER_VALIDATE_EMAIL) || $celular === "" ||
        $grupo === "" || $fecha_nacimiento === "" || $genero === "") {
        die("Completa correctamente todos los campos del formulario.");
    }

    // Actualizar los campos mediante una sentencia preparada.
    $sql = "UPDATE usuarios SET
            nombre = ?,
            documento = ?,
            usuario = ?,
            correo = ?,
            celular = ?,
            grupo = ?,
            fecha_nacimiento = ?,
            genero = ?
            WHERE id = ?";

    $stmt = $conexion->prepare($sql);

    if (!$stmt) {
        die("No se pudo preparar la actualización: " . $conexion->error);
    }

    $stmt->bind_param(
        "ssssssssi",
        $nombre,
        $documento,
        $usuario_nombre,
        $correo,
        $celular,
        $grupo,
        $fecha_nacimiento,
        $genero,
        $id
    );

    if ($stmt->execute()) {

        header("Location: usuarios.php?mensaje=actualizado");
        exit();

    } else {

        echo "Error al actualizar: " . $stmt->error;
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Editar usuario - Ecopatrulla</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #e8f5e9;
            margin: 0;
            padding: 30px;
        }

        .contenedor {
            max-width: 600px;
            margin: auto;
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }

        h1 {
            text-align: center;
            color: #1b5e20;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        button {
            width: 100%;
            margin-top: 25px;
            padding: 12px;
            background-color: #2e7d32;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #1b5e20;
        }

        .volver {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #2e7d32;
            text-decoration: none;
        }

    </style>

</head>

<body>

    <div class="contenedor">

        <h1>Editar usuario</h1>

        <form method="POST">

            <label>Nombre completo</label>

            <input type="hidden" name="id" value="<?php echo (int) $id; ?>">

            <input
                type="text"
                name="nombre"
                value="<?php echo htmlspecialchars($usuario["nombre"]); ?>"
                required
            >


            <label>Documento</label>

            <input
                type="text"
                name="documento"
                value="<?php echo htmlspecialchars($usuario["documento"]); ?>"
                required
            >


            <label>Usuario</label>

            <input
                type="text"
                name="usuario"
                value="<?php echo htmlspecialchars($usuario["usuario"]); ?>"
                required
            >


            <label>Correo</label>

            <input
                type="email"
                name="correo"
                value="<?php echo htmlspecialchars($usuario["correo"]); ?>"
                required
            >


            <label>Celular</label>

            <input
                type="text"
                name="celular"
                value="<?php echo htmlspecialchars($usuario["celular"]); ?>"
                required
            >


            <label>Grupo</label>

            <select name="grupo" required>

                <option value="10-1" <?php if ($usuario["grupo"] == "10-1") echo "selected"; ?>>10-1</option>
                <option value="10-2" <?php if ($usuario["grupo"] == "10-2") echo "selected"; ?>>10-2</option>
                <option value="10-3" <?php if ($usuario["grupo"] == "10-3") echo "selected"; ?>>10-3</option>
                <option value="10-4" <?php if ($usuario["grupo"] == "10-4") echo "selected"; ?>>10-4</option>
                <option value="10-5" <?php if ($usuario["grupo"] == "10-5") echo "selected"; ?>>10-5</option>
                <option value="10-6" <?php if ($usuario["grupo"] == "10-6") echo "selected"; ?>>10-6</option>
                <option value="10-7" <?php if ($usuario["grupo"] == "10-7") echo "selected"; ?>>10-7</option>

                <option value="11-1" <?php if ($usuario["grupo"] == "11-1") echo "selected"; ?>>11-1</option>
                <option value="11-2" <?php if ($usuario["grupo"] == "11-2") echo "selected"; ?>>11-2</option>
                <option value="11-3" <?php if ($usuario["grupo"] == "11-3") echo "selected"; ?>>11-3</option>
                <option value="11-4" <?php if ($usuario["grupo"] == "11-4") echo "selected"; ?>>11-4</option>
                <option value="11-5" <?php if ($usuario["grupo"] == "11-5") echo "selected"; ?>>11-5</option>
                <option value="11-6" <?php if ($usuario["grupo"] == "11-6") echo "selected"; ?>>11-6</option>
                <option value="11-7" <?php if ($usuario["grupo"] == "11-7") echo "selected"; ?>>11-7</option>

            </select>


            <label>Fecha de nacimiento</label>

            <input
                type="date"
                name="fecha_nacimiento"
                value="<?php echo $usuario["fecha_nacimiento"]; ?>"
                required
            >


            <label>Género</label>

            <select name="genero" required>

                <option value="Masculino" <?php if ($usuario["genero"] == "Masculino") echo "selected"; ?>>
                    Masculino
                </option>

                <option value="Femenino" <?php if ($usuario["genero"] == "Femenino") echo "selected"; ?>>
                    Femenino
                </option>

                <option value="Otro" <?php if ($usuario["genero"] == "Otro") echo "selected"; ?>>
                    Otro
                </option>

                <option value="Prefiero no decirlo" <?php if ($usuario["genero"] == "Prefiero no decirlo") echo "selected"; ?>>
                    Prefiero no decirlo
                </option>

            </select>


            <button type="submit">
                Guardar cambios
            </button>

        </form>

        <a href="usuarios.php" class="volver">
            ← Volver a usuarios
        </a>

    </div>

</body>

</html>